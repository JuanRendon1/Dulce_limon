<?php
$conexion = mysqli_connect("localhost", "root", "", "dulcelimon") or
    die("Problemas con la conexión");
?>